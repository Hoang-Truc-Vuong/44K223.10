<?php
$seo = dokan_pro()->store_seo;
?>

<div class="dokan-store-seo-wrapper">
    <?php $seo->frontend_meta_form(); ?>
</div>


