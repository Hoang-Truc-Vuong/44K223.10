<?php
/**
 *  Dashboard No Coupon template
 *
 *  @since 2.4
 *
 *  @package dokan
 */
?>

<div class="dokan-error">
    <?php echo $message; ?>
</div>